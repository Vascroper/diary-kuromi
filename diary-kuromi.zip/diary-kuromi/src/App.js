
import DiaryApp from './DiaryApp';

function App() {
  return <DiaryApp />;
}

export default App;
